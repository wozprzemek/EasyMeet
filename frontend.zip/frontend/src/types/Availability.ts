export interface Availability {
    user: string;
    time: string;
    meeting: string;
}