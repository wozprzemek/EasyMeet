export enum ButtonType {
    TEXT,
    OUTLINE,
    OUTLINE_GRAY,
    SOLID,
    CIRCLE
}

export enum ButtonSize {
    SM,
    LG,
}
