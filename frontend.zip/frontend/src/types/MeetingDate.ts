export interface MeetingDate {
    id: string;
    date: string;
    meeting: string;
}