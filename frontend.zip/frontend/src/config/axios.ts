import Axios from 'axios';
import { API_URL } from 'config';

export const axios = Axios.create({
  baseURL: "/api",  
});

axios.interceptors.response.use(
  undefined,
  (error) => {
    return Promise.reject(error);
  }
);